# tasks/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Group, Announcement
from .forms import AnnouncementForm  # まだ作っていない場合は後述

@login_required
def announcement_list(request, group_id):
    group = get_object_or_404(Group, pk=group_id)
    announcements = group.announcements.order_by('-created_at')
    return render(request, 'tasks/announcement_list.html', {
        'group': group,
        'announcements': announcements,
    })

@login_required
def announcement_create(request, group_id):
    group = get_object_or_404(Group, pk=group_id)
    if request.method == 'POST':
        form = AnnouncementForm(request.POST)
        if form.is_valid():
            announcement = form.save(commit=False)
            announcement.group = group
            announcement.created_by = request.user
            announcement.save()
            return redirect('announcement_list', group_id=group.id)
    else:
        form = AnnouncementForm()
    return render(request, 'tasks/announcement_form.html', {
        'group': group,
        'form': form,
    })
