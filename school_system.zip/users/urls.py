from django.contrib import admin
from django.urls import path, include
from django.urls import path
from . import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("tasks/", include("tasks.urls")),
    path("users/", include("users.urls")),  # 🔥 追加
    path("", include("dashboard.urls")),  # 🔥 ダッシュボードを後で作成
    path('dashboard/', views.dashboard, name='dashboard'),
    # 例として、グループ詳細ページの URL も追加する場合
    path('group/<int:group_id>/', views.group_detail, name='group_detail'),
]